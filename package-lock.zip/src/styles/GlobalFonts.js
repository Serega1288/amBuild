import {createGlobalStyle} from "styled-components";

import Inter from '../assets/fonts/Inter/Inter-Regular.woff2';
import InterBold from '../assets/fonts/Inter/Inter-Bold.woff2';
import InterMedium from '../assets/fonts/Inter/Inter-Medium.woff2';

const GlobalFonts = createGlobalStyle`
@font-face {
    font-family: 'Inter';
    font-style: normal; 
    font-weight: 400; 
    src: url("${Inter}") format("woff2");
}
@font-face {
    font-family: 'Inter';
    font-style: normal;
    font-weight: 500;  
    src: url("${InterMedium}") format("woff2");
} 
@font-face {
    font-family: 'Inter'; 
    font-style: normal;
    font-weight: 700; 
    src: url("${InterBold}") format("woff2");
} 
// h1,h2,h3,h4 {
//         font-family: 'Bolkit';
//       }
`;
export default GlobalFonts;