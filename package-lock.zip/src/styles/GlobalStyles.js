import { createGlobalStyle } from 'styled-components';
import {minCol, maxCol} from "../function/SizeCol";


const GlobalStyles = createGlobalStyle`  
.ovh {
    overflow: hidden;
}
img {  
    max-width: 100%;
}
/* width */
::-webkit-scrollbar {
  width: 2px;
  height: 4px;
}
// #86644B
/* Track */
::-webkit-scrollbar-track {
  background-color: #f7f4ed; 
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: #86644B;
}

.grey { 
    //filter: grayscale(100%);
}
.grey_off { 
    filter: none;
}
 
.pos {
    position: relative;
}
.z-in-1 {
    z-index: 1;
}
.z-in-2 {
    z-index: 2;
}
.h100 {
    height: 100%;
} 
.w100 {
    width: 100%;
}

.ul-clear {
    margin: 0;
    padding: 0;   
}
.ul-clear li::marker {
   font-size: 0;
}

.p-0 {
    padding:0;
}
.m-0 {
    margin:0;
}

.text-center {
    text-align: center;
}

.body {
    overflow: hidden;   
}
 
p { 
    margin: 0 0 2rem;
    @media (max-width: ${maxCol.sm} ) {
        margin: 0 0 1rem;
    }
} 

html {
    font-size: 62.5%;
    --bs-gutter-x: 1.6rem;
    @media (min-width: ${minCol.sm} ) {
        font-size: 35%; 
    }
    
    @media (min-width: ${minCol.md} ) {
        
    }
    
    @media (min-width: ${minCol.lg} ) {
        font-size: 55%;
    }
    
    @media (min-width: ${minCol.xl}) {
        
    }
     
    @media (min-width: ${minCol.xxl}) {
        font-size: 62.5%;
    } 
}
 
body {
    min-height: 100vh;
    background-color: #F5F5F7; 
    margin: 0;
    font-size: 2rem; 
    line-height: 1.4;  
    font-family: 'Inter';
    color: #000;
    font-weight: 400;
    -webkit-text-size-adjust: 100%;
    -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    @media (max-width: ${maxCol.sm}) {

    }
} 
a {
    color: #6357FF;
    text-decoration: none;
}
ul {
    a {
        color: #6357FF;
        &:hover {
            color: #6357FF; 
        }
    }
}
.anim, a, .btn, .btn:before, .btn:after , input, a:after, a:before, a div {
    transition: all 0.5s ease;  
}
  
.a-style-clear {
    display: initial;
    text-decoration: none;
}
 
.btn {
    cursor: pointer; 
    display: inline-block;
    text-transform: uppercase;
    font-weight: 700;
    font-size: 1.2rem;
    line-height: 1;
    padding: 1rem 2.4rem;
    border: 1px solid #FFFFFF;
    border-radius: 50px;
    text-decoration: none;   
    color: #fff;
    &.style-1 {
        & +  &.style-1 { 
            margin-left:1.2rem;
        } 
        &:hover, &:focus, &[aria-current="page"] { 
            background-color: #FFFFFF;
            color: #000;
        }
    } 
} 
      
.garbage {
        position: absolute;
       height: 0 !important; 
       width: 0 !important; 
       opacity: 0 !important;
       z-index: -1000 !important;
}
`;

export default GlobalStyles;
