import React from 'react';

import Content from "./content/Content";
import Banner from "./banner/Banner";
import BlockTabs from "./tabs/BlockTabs";
import SliderContent from "./slider/SliderContent";
import SliderImage from "./slider/SliderImage";


const Const = ( { item, href, type } ) => {
    console.log('>>', item );
    return (
        <>
            { item.fieldGroupName ? (
                <>
                    { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Content` ? ( <Content item={item} /> ) : null }
                    {/*{ item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Banner` ? ( <Banner item={item} /> ) : null }*/}
                    {/*{ item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_BlockTabs` ? ( <BlockTabs item={item} /> ) : null }*/}
                    {/*{ item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_SliderContent` ? ( <SliderContent item={item} /> ) : null }*/}
                    {/*{ item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_SliderImage` ? ( <SliderImage item={item} /> ) : null }*/}

            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Banner` ? ( <Banner item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Collections` ? ( <Collections item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Videovoutube` ? ( <Video item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Instagram` ? ( <Instagram item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Slider` ? ( <Slider item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Title` ? ( <Title item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_ContentTextImgImg` ? ( <Content1 item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_ContentImgTitleText` ? ( <Content2 item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Collaps` ? ( <Collaps item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Content` ? ( <Content3 item={item} /> ) : null }*/}

            {/*        { item.fieldGroupName === `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Contactdata` ? ( <Contactdata item={item} /> ) : null }*/}
            {/*        { item.fieldGroupName == `${type ? 'Post' : 'Page'}_Acfconstructor_Const_Contactform` ? ( <Contactform href={href} item={item} /> ) : null }*/}

                </>
            ) : null }
        </>
    )
};
export default Const;