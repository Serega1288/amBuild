import React from "react";
import Field from "./ContactFormField";

export default class ContactFormItem extends React.Component {

    render () {
        //console.log('ss', props)
        return (
            <>
            </>
            // <form className='formStyle2'>
            //     {props.item.form.map( (item, index) => (
            //         <Field key={index} i={index+1} item={item} ind={props.ind} />
            //     ))}
            // </form>
        )
    }

}

// const ContactFormItem = ( { item, ind } ) => {
//     return (
//
//     )
// }
// export default ContactFormItem;
