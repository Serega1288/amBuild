const path = require('path');


//const frontTemplate = path.resolve('./src/templates/FrontPage.js')
const pageTemplate = path.resolve(`./src/templates/page.js`)
const pageTemplateConstructor = path.resolve(`./src/templates/pageConstructor.js`)
//const postTemplate = path.resolve(`./src/templates/post.js`)
//const blogTemplate = path.resolve(`./src/templates/blog.js`)
// const categoryProductTemplate = path.resolve(`./src/templates/CategoryProduct.js`)
// const productTemplate = path.resolve(`./src/templates/Product.js`)

//
// const createBlogPage = (createPage, posts) => {
//
//     const { nodes } = posts;
//     const postsPerPage = 4;
//     const numPages = Math.ceil(nodes.length / postsPerPage);
//
//     Array.from({length: numPages}).forEach((_,i) =>{
//         createPage({
//             path: i === 0 ? '/blog/' : `/blog/page/${i + 1}`,
//             component: blogTemplate,
//             context: {
//                 limit: postsPerPage,
//                 skip: i * postsPerPage,
//                 numPages,
//                 currentPage: i + 1,
//             }
//         })
//     })
// }

exports.createPages = ({graphql, actions}) => {
    const {createPage} = actions;

    return graphql(`
        { 
          page:allWpPage {
            nodes {
              slug
              title
              content
              isFrontPage  
              template {
                templateName
              } 
              ACFconstructor {
                  const { 
                    ... on WpPage_Acfconstructor_Const_Content {
                      alignhor
                      alignver
                      fieldGroupName
                      style
                      text
                      title
                    }
                    ... on WpPage_Acfconstructor_Const_Banner {
                      alignhor
                      fieldGroupName
                      text
                      title
                      banner {
                        localFile {
                          publicURL
                        }
                      }
                    }
                    ... on WpPage_Acfconstructor_Const_BlockTabs {
                      fieldGroupName
                      title
                      tabs {
                        fieldGroupName
                        title
                        list {
                          title
                          editir
                        }
                      }
                    }
                    ... on WpPage_Acfconstructor_Const_SliderContent {
                      fieldGroupName
                      title
                      slider {
                        title
                        text
                        subTitle
                        icon {
                          localFile {
                            publicURL
                          }
                        }
                      }
                    }
                    ... on WpPage_Acfconstructor_Const_SliderImage {
                      fieldGroupName
                      slider {
                        url
                        image {
                          localFile {
                            publicURL
                          }
                        }
                      }
                    }
                  }
              } 
            }
          }
        } 
    `).then(results => {
        if (results.error) {
            throw  results.errors;
        }
        //const  { posts, categories } = results.data;
        // console.log('posts >>', posts.nodes)
        //console.log('categories >>', categories.nodes)


        // 1. cread pages do post
        // posts.nodes.forEach((post, index) => {
        //     const  previous = index === posts.nodes.length - 1 ? null : posts.nodes[index + 1];
        //     const  next = index === 0 ? null : posts.nodes[index - 1];
        //
        //     createPage({
        //         path: `${post.slug.current}`,
        //         component: postTemplate,
        //         context: {
        //             slug: post.slug.current,
        //             previous,
        //             next,
        //         }
        //     })
        // });

        // 2. home page
        //createFrontPage( createPage )


        // categoty  categoryTemplate


        results.data.page.nodes.forEach(item => {

            if ( item.isFrontPage === true ) {

                createPage({
                    path: '/',
                    component:  pageTemplate,
                    context: item,
                })

            } else {

                // console.log('templateName >>', item.template.templateName)

                if ( item.template.templateName === 'Constructor') {
                    createPage({
                        path: `${item.slug}`,
                        component:  pageTemplateConstructor,
                        context: item,
                    })
                } else {
                    createPage({
                        path: `${item.slug}`,
                        component:  pageTemplate,
                        context: item,
                    })
                }


            }

        });




    });
};